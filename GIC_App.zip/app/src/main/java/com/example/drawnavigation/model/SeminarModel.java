package com.example.drawnavigation.model;

public class SeminarModel {
//    private int id;
//String text;
    String title ;
    String start_date;
    String end_date;
    String logo;
    String short_description;


    public SeminarModel(String title, String start_date, String end_date, String logo, String short_description) {
//        this.id = id;
        this.title = title;
        this.start_date = start_date;
        this.end_date = end_date;
        this.logo = logo;
        this.short_description = short_description;

    }

    public String getTitle()
    {
        return title;
    }



    public String getStart_date()
    {
        return start_date;
    }

    public String getEnd_date() { return end_date; }

    public String getLogo() {
        return logo;
    }
    public String getShort_description()
    {
        return short_description;
    }

}
