package com.example.drawnavigation.adapters;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.drawnavigation.R;
import com.example.drawnavigation.model.ScholarshipModel;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import androidx.recyclerview.widget.RecyclerView;

public class ScholarshipAdapter extends RecyclerView.Adapter<ScholarshipAdapter.ViewHolder> {
    private ArrayList<ScholarshipModel> dataList;
    private Context mContext;

    public ScholarshipAdapter(Context context, ArrayList<ScholarshipModel> exampleList) {
        mContext = context;
        dataList = exampleList;
    }


    public class ViewHolder extends RecyclerView.ViewHolder
    {

        public TextView textViewTitle;
        //        public TextView textViewComment;
        public TextView textViewDate;
//        public TextView textViewSart_date;
//        public ImageView logo;
        public TextView textViewShort_description;

        public ViewHolder(View itemView)
        {
            super(itemView);
            this.textViewTitle = (TextView) itemView.findViewById(R.id.title);
//            this.textViewComment = (TextView) itemView.findViewById(R.id.comment);
            this.textViewDate = (TextView) itemView.findViewById(R.id.start_date);
//            this.textViewEnd_date = (TextView) itemView.findViewById(R.id.end_date);
            this.textViewShort_description = (TextView) itemView.findViewById(R.id.short_description);
//            this.logo = (ImageView) itemView.findViewById(R.id.logo);
        }
    }
    @Override
    public ScholarshipAdapter.ViewHolder onCreateViewHolder( ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview_item, parent, false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        ScholarshipModel currentItem = dataList.get(position);
//        String logo = currentItem.getLogo();

        holder.textViewTitle.setText(dataList.get(position).getTitle());
        holder.textViewDate.setText(dataList.get(position).getDate());
//        holder.textViewEnd_date.setText(dataList.get(position).getEnd_date());
        holder.textViewShort_description.setText(dataList.get(position).getShort_description());
        //holder.imageView.setImageResource(dataList.get(position).getImageUrl());
//        Picasso.get().load(logo).fit().centerInside().into(holder.logo);

        holder.itemView.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

            }
        });

    }




    @Override
    public int getItemCount()  { return dataList.size(); }

}

