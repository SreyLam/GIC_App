package com.example.drawnavigation;

public class SeminarsList {


    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }


    public SeminarsList(String name) {
        Name = name;
    }
    private String Name;

}
