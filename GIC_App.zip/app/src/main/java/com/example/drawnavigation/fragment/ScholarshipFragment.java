package com.example.drawnavigation.fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.drawnavigation.DataNote;
import com.example.drawnavigation.R;
import com.example.drawnavigation.adapters.ScholarshipAdapter;
import com.example.drawnavigation.model.ScholarshipModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class ScholarshipFragment extends Fragment {

//    private TextView mTextViewEmpty;
//    private ProgressBar mProgressBarLoading;
    private ImageView mImageViewEmpty;
    private RecyclerView mRecyclerView;
    private ScholarshipAdapter scholarshipadapter;
    private ArrayList<ScholarshipModel> dataList;
    private RequestQueue mRequestQueue;


    public ScholarshipFragment(){}


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view  = inflater.inflate(R.layout.fragment_scholarship, container, false);

        mRecyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);


        final LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(layoutManager);

        dataList = new ArrayList<>();

        mRequestQueue = Volley.newRequestQueue(getActivity());

        sendGetRequest();

        return view;
    }


    private void sendGetRequest() {

        mRequestQueue = Volley.newRequestQueue(getActivity());
        final String url = "https://gic.itc.edu.kh/api/v2/scholarships";

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("data");
//                            JSONObject jsonObject1 = new JSONObject(jsonObject.toString());
//                            JSONObject jsonObject2 = jsonObject1.getJSONObject("title");
//                            JSONObject jsonObject3 = jsonObject2.getJSONObject("date");
//                            JSONObject jsonObject4 = jsonObject3.getJSONObject("short_description");
//                            JSONObject jsonArray = response();
//
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject hit = jsonArray.getJSONObject(i);

                                String title = hit.getString("title");
                                String date = hit.getString("date");
                                String short_description = hit.getString("short_description");
//                                String imageUrl = hit.getString("image");
                                dataList.add(new ScholarshipModel(title,date,short_description));
                            }

                            scholarshipadapter = new ScholarshipAdapter(getActivity(), dataList);
                            mRecyclerView.setAdapter(scholarshipadapter);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        mRequestQueue.add(request);
    }

}