package com.example.drawnavigation.model;

public class PartnershipModel {
    String name ;
    String logo;
//    String website;


    public PartnershipModel(String name, String logo) {
//        this.id = id;
        this.name = name;
        this.logo = logo;

    }

    public String getName()
    {
        return name;
    }

    public String getLogo() { return logo; }


}



