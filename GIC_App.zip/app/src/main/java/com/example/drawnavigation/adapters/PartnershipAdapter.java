package com.example.drawnavigation.adapters;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.drawnavigation.R;
import com.example.drawnavigation.model.PartnershipModel;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class PartnershipAdapter extends RecyclerView.Adapter<PartnershipAdapter.ViewHolder> {
//    private ArrayList newList;
private ArrayList<PartnershipModel> dataList;
    private Context mContext;

    public PartnershipAdapter(Context context, ArrayList<PartnershipModel> exampleList) {
        mContext = context;
        dataList = exampleList;
    }


    public class ViewHolder extends RecyclerView.ViewHolder
    {

        public TextView textViewName;
        public TextView textViewDate;
        public ImageView logo;
        public ViewHolder(View itemView)
        {
            super(itemView);
            this.textViewName = (TextView) itemView.findViewById(R.id.name);

            this.logo = (ImageView) itemView.findViewById(R.id.logo);
        }
    }
    @Override
    public PartnershipAdapter.ViewHolder onCreateViewHolder( ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview_item, parent, false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        PartnershipModel currentItem = dataList.get(position);
        String logo = currentItem.getLogo();

        holder.textViewName.setText(dataList.get(position).getName());
        //holder.imageView.setImageResource(dataList.get(position).getImageUrl());
        Picasso.get().load(logo).fit().centerInside().into(holder.logo);

        holder.itemView.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

            }
        });

    }




    @Override
    public int getItemCount()  { return dataList.size(); }

}


