package com.example.drawnavigation.fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.drawnavigation.DataNote;
import com.example.drawnavigation.R;
import com.example.drawnavigation.adapters.PartnershipAdapter;
import com.example.drawnavigation.model.PartnershipModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import androidx.fragment.app.Fragment;

//import com.example.drawnavigation.adapters.PartnershipAdapter;


/**
 * A simple {@link Fragment} subclass.
 */
public class PartnershipFragment extends Fragment {
    private TextView mTextViewEmpty;
    private ImageView mImageViewEmpty;
    private RecyclerView mRecyclerView;
    private PartnershipAdapter partnershipAdapter;
    private ArrayList<PartnershipModel> dataList;
    private RequestQueue mRequestQueue;



    public PartnershipFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view  = inflater.inflate(R.layout.fragment_partnership, container, false);

        mRecyclerView = (RecyclerView) view.findViewById(R.id.recyclerView3);


        final LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(layoutManager);

        dataList = new ArrayList<>();

        mRequestQueue = Volley.newRequestQueue(getActivity());

        sendGetRequest();

        return view;
    }

    private void sendGetRequest() {

        mRequestQueue = Volley.newRequestQueue(getActivity());
        final String url = "https://gic.itc.edu.kh/api/v2/partners";
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        try {
                            JSONArray jsonArray = response.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject hit = jsonArray.getJSONObject(i);

                                String name = hit.getString("name");
                                String logo = hit.getString("logo");
                                dataList.add(new PartnershipModel(name,logo));
                            }
////
                            partnershipAdapter = new PartnershipAdapter(getActivity(), dataList);
                            mRecyclerView.setAdapter(partnershipAdapter);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        mRequestQueue.add(request);
    }

}
