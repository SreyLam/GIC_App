package com.example.drawnavigation.model;

public class ScholarshipModel {
    String title ;
    String date;
//    String end_date;
//    String logo;
    String short_description;


    public ScholarshipModel(String title, String date, String short_description) {
//        this.id = id;
        this.title = title;
        this.date = date;
//        this.end_date = end_date;
//        this.logo = logo;
        this.short_description = short_description;

    }

    public String getTitle()
    {
        return title;
    }



    public String getDate()
    {
        return date;
    }

//    public String getEnd_date() { return end_date; }

//    public String getLogo() {
//        return logo;
//    }
    public String getShort_description()
    {
        return short_description;
    }

}


