package com.example.drawnavigation.extra;



public interface Keys {


        String KEY_ACCESS_KEY="accessKey";
        String KEY_ACCESS_KEY_VALUE="camitss";
        String KEY_EMPLOYEE_ID="employeeID";
        String KEY_CODE="code";
        String KEY_MESSAGE="message";
        String KEY_DATA="data";

        // seminar screen list
        String KEY_NAME = "name";
        String KEY_DATE = "start_date";

}
