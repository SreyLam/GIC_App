package com.example.drawnavigation.fragment;

class DataNoteImformation {
    public static String[] textArray = {"Lightshot 截圖工具", "Lightshot 截圖工具"};
    public static String[] dateArray = {"2017-04-25", "2017-04-25"};
    public static String[] id = {"1", "2"};
}
